function showtime() {
    let date = new Date();
    let class = document.getElementById("Clock").innerHTML
}